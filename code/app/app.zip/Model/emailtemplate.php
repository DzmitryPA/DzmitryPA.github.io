<?php
class Emailtemplate extends AppModel{
	var $name	= 'Emailtemplate';
       
}
?>